import pygame
from random import randint

BLACK = (  0,   0,   0)
WHITE = (255, 255, 255)
RED   = (255,   0,   0)
GREEN = (  0, 255,   0)
BLUE  = (  0,   0, 255)

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCREEN_BORDER = 10

VELOCITY = 3
FRAMERATE = 40

_image_library = {}
def get_image(path):    
    image = pygame.image.load(path)
    return image
    global _image_library
    image = _image_library.get(path)
    if image == None:
            canonicalized_path = path.replace('/', os.sep).replace('\\', os.sep)
            image = pygame.image.load(canonicalized_path)
            _image_library[path] = image
    return image

def playEatSound():
    pygame.mixer.music.load("eatSound.wav")
    pygame.mixer.music.play()

class Background(pygame.sprite.Sprite):
    def __init__(self, image_file, location):
        pygame.sprite.Sprite.__init__(self)  #call Sprite initializer
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location

class Building(pygame.sprite.Sprite):
    def __init__(self, x, y, height, width):
        super().__init__()
        self.image = get_image('tile.png')
        self.rect = pygame.Rect(x, y, height, width)

    def move(self, x, y):
            self.rect.x += x
            self.rect.y += y

    def update(self):
        self.move(-5,0)
        if self.rect.x < -self.rect.width:
            self.rect.x = SCREEN_WIDTH

class Player(pygame.sprite.Sprite):
    """
    This class represents the ball.
    It derives from the "Sprite" class in Pygame.
    """
 
    def __init__(self):
 
        # Call the parent class (Sprite) constructor
        super().__init__()
 
        self.images = []
        self.images.append(get_image('pacman1.png'))
        self.images.append(get_image('pacman2.png'))
        self.images.append(get_image('pacman3.png'))
        self.images.append(get_image('pacman2.png'))
        
        self.index = 0
        self.image = self.images[self.index]
        
        self.rect = pygame.Rect(5, 5, 64, 64)

    def move(self, x, y):
            self.rect.x += x
            self.rect.y += y

    def update(self):
        '''This method iterates through the elements inside self.images and 
        displays the next one each tick. For a slower animation, you may want to 
        consider using a timer of some sort so it updates slower.'''

        imageTicks = 5 # number of loops each animation frame shows for
        self.index += 1
        if self.index >= len(self.images)*imageTicks:
            self.index = 0
        imageCount = int(self.index/imageTicks)
        self.image = self.images[imageCount]

class Runner :

    RADIUS = 10 

    def __init__(self,x,y,vx,vy):
        self.x = x
        self.y = y
        self.vx = vx # remove?
        self.vy = vy
        self.moving = False

    def show(self,col):
        pygame.draw.circle(screen,col,(self.x, self.y),self.RADIUS)

class Map :

    def __init__(self,x,y,width,height,vx):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vx = vx
        self.moving = False

    def show(self,col):
        pygame.draw.rect(screen, col, pygame.Rect(self.x, self.y, self.width, self.height))

class BuildingFactory():
    def __init__(self,screen):
        self.screen = screen
        self.building_group = pygame.sprite.Group()
        self.counter = 0

    def makeBuilding(self):
        building = Building(SCREEN_WIDTH,randint(1, 3)*100,randint(5, 10)*100,100)
        building.add(self.building_group)

    def update(self):
        self.building_group.update()
        self.building_group.draw(self.screen)

        self.counter -= 1
        if self.counter < 1 :
            self.counter = 50
            self.makeBuilding()

pygame.mixer.pre_init(44100, -16, 2, 2048)
pygame.init() # starts creating
screen = pygame.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])# creates screen
screen.fill(pygame.Color("black"))# gives screen black color
background = Background('background.png', [0,0])
factory = BuildingFactory(screen)
player = Player()
player_group = pygame.sprite.Group(player)
runner = Runner(int((SCREEN_WIDTH-Runner.RADIUS)/4), int((SCREEN_HEIGHT-Runner.RADIUS)*2/3), 0, 0)
map = Map(0, int((SCREEN_HEIGHT-Runner.RADIUS)*2/3)+10, SCREEN_WIDTH, 10, 0)
map.show(pygame.Color("blue"))
runner.show(pygame.Color("green"))
done = False

while not done:
    for event in pygame.event.get():
    	# add button logic for jumping, etc
        if event.type == pygame.QUIT:
            done = True
        


    screen.fill(WHITE)
    screen.blit(background.image, background.rect)

    pressed = pygame.key.get_pressed()
    if pressed[pygame.K_UP]: player.move(0,-3)
    if pressed[pygame.K_DOWN]: player.move(0,3)
    if pressed[pygame.K_LEFT]: player.move(-3,0)
    if pressed[pygame.K_RIGHT]: player.move(3,0)
    factory.update()
    player_group.update()
    player_group.draw(screen)
    for building in factory.building_group :
        if player.rect.colliderect(building.rect):
            building.kill()
            playEatSound()

    pygame.display.flip()

